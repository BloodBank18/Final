﻿using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankMangementSystem.DAL
{
    public class BloodInventoryDL
    {
        //Creating Connection
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static BloodInventoryDL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public BloodInventoryDL()
        {
            con = new SqlConnection(conStr);

        }

        //Display blood inventory details using stored procedures
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public DataTable BloodInventoryDisplay()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspDisplayInventory";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (BloodBankExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

        //Getting blood bank names using stored procedures
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public DataTable GetAllBloodBankName()
        {
            DataTable bloodBankName = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspGetAllName";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    bloodBankName = new DataTable();
                    bloodBankName.Load(dr);
                }



            }

            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return bloodBankName;
        }

        //getting blood group using stored procedures
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public DataTable GetRespectiveBloodGroup(string selectedItem)
        {
            DataTable dt = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspGetAllBloodGroup";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@BloodBankIDFrom", selectedItem);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;

        }

        //transfer blood from one bank to another bank
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public int TransferBlood(string fromBloodBank, string toBloodBank, int noofBottles,string bloodGroup)
        {
            int transfer = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspBloodTransfer";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@bloodBankIDFrom", fromBloodBank);
                cmd.Parameters.AddWithValue("@bloodBankIDTo", toBloodBank);
                cmd.Parameters.AddWithValue("@numberofBottles", noofBottles);
                cmd.Parameters.AddWithValue("@bloodGroup", bloodGroup);

                cmd.ExecuteNonQuery();
                transfer = 1;
            }
            catch (Exception)
            {

                throw;
            }
            return transfer;
        }

        //Delete blood inventory details using stored procedures
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public bool DeleteBloodInventory(DateTime ExpiryDate)
        {
            bool result = false;
            try
            {

                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspDeleteBloodInventory";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ExpiryDate", ExpiryDate);

                con.Open();
                cmd.ExecuteNonQuery();
                
                result = true;
                
            }
            catch (BloodBankExceptions)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        //Update blood inventory details using stored procedures
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public bool EditBloodInventory(BloodInventory pboj)
        {
            bool result = false;
            try
            {
                // con = new SqlConnection();
                //   con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspEditBloodInventory";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@bId", pboj.BloodInvenoryID);
                cmd.Parameters.AddWithValue("@BloodGroup", pboj.BloodGroup);
                cmd.Parameters.AddWithValue("@noofbottle", pboj.NumberOfBottles);
                cmd.Parameters.AddWithValue("@BloodBankId", pboj.BloodBankID);
                cmd.Parameters.AddWithValue("@expiryDate", pboj.ExpiryDate);
                //cmd.Parameters.AddWithValue("@hid", pboj.HospitalID);

                con.Open();
                cmd.ExecuteNonQuery();
                
                    result = true;
                    
                
            }
            catch (BloodBankExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        //Search blood inventory details using stored procedures
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public BloodInventory Search(int searchInventory)
        {
            BloodInventory p = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspSearchBloodInventory";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@bId", searchInventory);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new BloodInventory
                    {

                        BloodGroup = dr["BloodGroup"].ToString(),
                        NumberOfBottles = int.Parse(dr["NumberofBottles"].ToString()),
                        BloodBankID = (dr["BloodBankID"].ToString()),
                        ExpiryDate = DateTime.Parse((dr["ExpiryDate"].ToString())),
                        // HospitalID = int.Parse(dr["HospitalId"].ToString())
                    };
                    dr.Close();
                }
            }
            catch (BloodBankExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }

        public int BloodTransfer()
        {
            int transfer = 0;
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
            return transfer;
        }
    }
}
